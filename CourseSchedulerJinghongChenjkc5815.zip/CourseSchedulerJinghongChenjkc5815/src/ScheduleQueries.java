/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.sql.*;
import java.util.*;

/**
 *
 * @author chen
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class ScheduleQueries {
    private static Connection connection;
    private static ArrayList<String> faculty = new ArrayList<String>();
    private static PreparedStatement addScheduleEntry;
    private static PreparedStatement getScheduleByStudent;
    private static PreparedStatement getScheduledStudentCount;
    private static PreparedStatement getScheduledStudentsByCourse;
    private static PreparedStatement getWaitlistedStudentsByCourse;
    private static PreparedStatement dropStudentScheduleByCourse;
    private static PreparedStatement dropScheduleByCourse;
    private static PreparedStatement updateScheduleEntry;
    private static ResultSet resultSet1;
    private static ResultSet resultSet2;
    private static ResultSet resultSet3;
    private static ResultSet resultSet4;
    
    public static void addScheduleEntry(ScheduleEntry entry)
    {
        connection = DBConnection.getConnection();
        try
        {
            addScheduleEntry = connection.prepareStatement("insert into app.Schedule (semester, courseCode, StudentID, Status, Timestamp ) values (?,?,?,?,?)");
            addScheduleEntry.setString(1, entry.getSemester());
            addScheduleEntry.setString(2, entry.getCourseCode());
            addScheduleEntry.setString(3, entry.getStudentID());
            addScheduleEntry.setString(4, entry.getStatus());
            addScheduleEntry.setTimestamp(5, entry.getTimestamp());
            addScheduleEntry.executeUpdate();
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        
    }
    public static ArrayList<ScheduleEntry> getScheduleByStudent(String semester, String studentID)
    {
        
        connection = DBConnection.getConnection();
        ArrayList<ScheduleEntry> schedule = new ArrayList<>();
        try
        {
            //System.out.println(semester);
            //System.out.println(studentID);
            getScheduledStudentCount = connection.prepareStatement("select semester, courseCode, StudentID, Status, Timestamp from app.Schedule where semester=? AND studentID=?");
            getScheduledStudentCount.setString(1, semester);
            getScheduledStudentCount.setString(2, studentID);
            resultSet1 = getScheduledStudentCount.executeQuery();
            
            while(resultSet1.next())
            {
                ScheduleEntry object = new ScheduleEntry(resultSet1.getString(1), resultSet1.getString(2), resultSet1.getString(3), resultSet1.getString(4), resultSet1.getTimestamp(5) );
                schedule.add(object);
            }
            //System.out.println(schedule);
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        return schedule;
        
    }
    public static int  getScheduledStudentCount(String currentSemester, String courseCode)
    {
        connection = DBConnection.getConnection();
        int count = 0; 
        try
        {
            getScheduleByStudent = connection.prepareStatement("select count(StudentID) from app.Schedule where semester = ? and CourseCode = ?");
            getScheduleByStudent.setString(1, currentSemester);
            getScheduleByStudent.setString(2, courseCode);
            resultSet2 = getScheduleByStudent.executeQuery();
            resultSet2.next();
            count = resultSet2.getInt(1);

            
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        return count;
        
    }
    public static ArrayList<ScheduleEntry> getScheduledStudentsByCourse(String semester, String courseCode)
    {
        connection = DBConnection.getConnection();
        ArrayList<ScheduleEntry> scheduledstudent = new ArrayList<>();
        try
        {
            getScheduledStudentsByCourse = connection.prepareStatement("select semester,courseCode, StudentID, Status, Timestamp from app.Schedule where semester=? AND courseCode=?");
            getScheduledStudentsByCourse.setString(1, semester);
            getScheduledStudentsByCourse.setString(2, courseCode);
            resultSet3 = getScheduledStudentsByCourse.executeQuery();
            
            while(resultSet3.next())
            {   if (resultSet3.getString("Status").equals("S")){
                ScheduleEntry object = new ScheduleEntry(resultSet3.getString(1), resultSet3.getString(2), resultSet3.getString(3), resultSet3.getString(4), resultSet3.getTimestamp(5) );
                scheduledstudent.add(object);
            }
            }
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        return scheduledstudent;
        
    }
    public static ArrayList<ScheduleEntry> getWaitlistedStudentsByCourse(String semester, String courseCode)
    {
        connection = DBConnection.getConnection();
        ArrayList<ScheduleEntry> waitlistedstudent = new ArrayList<>();
        try
        { 
            getWaitlistedStudentsByCourse = connection.prepareStatement("select semester, courseCode, StudentID, Status, Timestamp from app.Schedule where semester=? AND courseCode=?");
            getWaitlistedStudentsByCourse.setString(1, semester);
            getWaitlistedStudentsByCourse.setString(2, courseCode);
            resultSet4 = getWaitlistedStudentsByCourse.executeQuery();
            
            while(resultSet4.next())
            {   if (resultSet4.getString("Status").equals("W")){
                   ScheduleEntry object = new ScheduleEntry(resultSet4.getString(1), resultSet4.getString(2), resultSet4.getString(3), resultSet4.getString(4), resultSet4.getTimestamp(5) );
                   waitlistedstudent.add(object);
                }
            
                
            }
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        return waitlistedstudent;
        
    }
    public static void dropStudentScheduleByCourse(String semester, String studentID, String courseCode)
    {
        connection = DBConnection.getConnection();
        try
        {
            dropStudentScheduleByCourse = connection.prepareStatement("delete from app.Schedule where semester=? AND studentID = ? AND courseCode =?");
            dropStudentScheduleByCourse.setString(1, semester);
            dropStudentScheduleByCourse.setString(2, studentID);
            dropStudentScheduleByCourse.setString(3, courseCode);
            dropStudentScheduleByCourse.executeUpdate();
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        
    }
    public static void dropScheduleByCourse(String semester, String courseCode)
    {
        connection = DBConnection.getConnection();
        try
        {
            dropScheduleByCourse = connection.prepareStatement("delete from app.Schedule where semester=? AND courseCode =?");
            dropScheduleByCourse.setString(1, semester);
            dropScheduleByCourse.setString(2, courseCode);
            dropScheduleByCourse.executeUpdate();
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        
    }
    public static void updateScheduleEntry(String semester, ScheduleEntry entry)
    {
        connection = DBConnection.getConnection();
        try
        {
            updateScheduleEntry = connection.prepareStatement("update app.Schedule SET Status = ? where semester=? AND studentID = ? AND courseCode =?");
            updateScheduleEntry.setString(1, "S");
            updateScheduleEntry.setString(2, entry.getStudentID());
            
            updateScheduleEntry.executeUpdate();
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        
    }
    
}
