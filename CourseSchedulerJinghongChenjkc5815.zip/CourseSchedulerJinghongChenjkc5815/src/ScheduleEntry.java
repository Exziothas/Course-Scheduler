

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.sql.Timestamp;
import java.util.Calendar;
import java.sql.*;
import java.util.*;

/**
 *
 * @author chen
 */
public class ScheduleEntry {
    private String semester; 
    private String courseCode; 
    private String StudentID; 
    private String  Status; 
    Timestamp Timestamp;
    
    public ScheduleEntry(String semester, String courseCode, String StudentID, String Status){
        this.semester = semester; 
        this.courseCode= courseCode; 
        this.StudentID= StudentID; 
        this. Status= Status; 
        this.Timestamp = new java.sql.Timestamp(Calendar.getInstance().getTime().getTime());
    }
    
    public ScheduleEntry(String semester, String courseCode, String StudentID, String Status, Timestamp timestamp){
        this.semester = semester; 
        this.courseCode= courseCode; 
        this.StudentID= StudentID; 
        this. Status= Status; 
        this.Timestamp = timestamp;
       
    }
    
    public String getSemester(){
        return semester; 
    }
    public String getCourseCode(){
        return courseCode; 
    }
    public String getStudentID(){
        return StudentID; 
    }
    public String getStatus(){
        return Status; 
    }
    
    public void setStatus(String status) {
        this.Status = status;
    }
    
    public Timestamp getTimestamp(){
        return Timestamp;
    }
}

