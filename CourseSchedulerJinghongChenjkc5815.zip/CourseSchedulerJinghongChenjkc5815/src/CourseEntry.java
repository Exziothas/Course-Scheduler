/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author chen
 */
public class CourseEntry {
    private String Semester, Coursecode, Description;
    private int Seats;
    
    public CourseEntry(String Semester, String Coursecode, String Description, int Seats){
        this.Semester=Semester;
        this.Coursecode=Coursecode;
        this.Description=Description;
        this.Seats=Seats;
    }
    
    public String getSemester(){
        return Semester;
    }
    public String getCourseCode(){
      return Coursecode;
    }

    public String getDescription(){
      return Description;
    }

    public int getSeats(){
      return Seats;
    } 
}
