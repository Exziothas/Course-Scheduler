/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author chen
 */
public class StudentEntry {
    
    private String studentID, firstName, lastName;
    
    public StudentEntry(String studentID, String firstName, String lastName){
        this.studentID=studentID;
        this.firstName=firstName;
        this.lastName=lastName;
    }
    
    public String toString(){
        return lastName+ ", " +firstName;
    
    }
    public String getStudentID(){
        return studentID;
    }
    
    public String getFirstName(){
        return firstName;
    }
    
    public String getLastName(){
        return lastName;
    }
    
    public String getFullName(){
        return getLastName() + ", " + getFirstName();
    }
     public String getStudentinfo(){
        return getLastName() + ", " + getFirstName()+' '+ getStudentID();
     }
}
